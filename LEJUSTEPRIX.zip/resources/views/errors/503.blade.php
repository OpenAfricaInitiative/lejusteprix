@extends('errors.base')
@section('title')
  @lang('Erreur 503')
@endsection
@section('text')
  @lang("Service temporairement indisponible ou en maintenance")
@endsection