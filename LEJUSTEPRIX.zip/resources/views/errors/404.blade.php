@extends('errors.base')
@section('title')
  @lang('Erreur 404')
@endsection
@section('text')
  @lang("Cette page n'existe pas")
@endsection