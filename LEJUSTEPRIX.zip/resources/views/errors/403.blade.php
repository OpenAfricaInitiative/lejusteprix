@extends('errors.base')
@section('title')
  @lang('Erreur 403')
@endsection
@section('text')
  @lang("Vos droits d'accès ne vous permettent pas d'accéder à cette ressource")
@endsection