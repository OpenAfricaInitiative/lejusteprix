<<<<<<< HEAD
# Album

Pour utiliser ce projet vous aurez besoin de du package <a href="https://github.com/cviebrock/eloquent-sluggable"> sluggable Eloquent</a> pour gerer les slug des differents categorie et 
bien sur <a href="https://laravel.com">Laravel</a> qui est le framework utilisée pour la realisation de ce projet.
=======
# lejusteprix
Une application conçu pour lutter contre la corruption et la vie chère  en cote d'ivoire
>>>>>>> 60578eb196ad772391d0fbc378f342419d4c2666
