<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produit extends Model
{
	$fillable=['name','pricebaby','priceint','slug','image']

}
